audit_stay_boundaries <- function(stays) {
 x <- data.table::copy(data.table::as.data.table(stays))
 x[, boundary_status := data.table::fcase(is.na(intime),'missing_intime',is.na(outtime),'missing_outtime',
     outtime<=intime,'nonpositive_stay',default='usable')]
 x[]
}
annotate_sofa <- function(sepsis) {
 x <- data.table::copy(data.table::as.data.table(sepsis))
 x[,sofa_without_cns := as.numeric(sofa_score-cns)]
 x[,sofa_needed_cns := ifelse(is.na(sofa_without_cns),NA,sofa_score>=2 & sofa_without_cns<2)]
 x[]
}

make_extraction_frame <- function(stays) {
 x <- audit_stay_boundaries(stays)
 x[,extraction_end := pmin(outtime,intime+14*86400)]
 x[is.na(outtime),extraction_end := intime+14*86400]
 x[,coverage_eligible := boundary_status=='usable']
 x[]
}

validate_recovery_manifest <- function(manifest, expected) {
 if (!'query' %in% names(manifest) || anyDuplicated(manifest$query) ||
     !setequal(manifest$query,expected)) stop('Recovery manifest is incomplete, duplicated or unexpected')
 invisible(TRUE)
}
