# Pure reconstruction functions. No credentials, network or file writes.
round_half_up <- function(x) floor(x + 0.5)
as_study_time <- function(x) as.POSIXct(x, tz='UTC')

build_gcs_assessments <- function(raw) {
  stopifnot(all(c('stay_id','charttime','itemid','value','valuenum') %in% names(raw)))
  d <- data.table::as.data.table(data.table::copy(raw))
  d[, charttime := as_study_time(charttime)]
  d <- d[!is.na(stay_id) & !is.na(charttime) & itemid %in% c(220739L,223900L,223901L)]
  if (!nrow(d)) stop('No GCS component records')
  d[, component := c('eye','verbal','motor')[match(itemid,c(220739L,223900L,223901L))]]
  d[, ett_value := itemid==223900L & !is.na(value) & trimws(value)=='No Response-ETT']
  d[, score := suppressWarnings(as.numeric(valuenum))]
  d[, upper := c(4,5,6)[match(component,c('eye','verbal','motor'))]]
  d[, bad_value := !ett_value & (!is.na(score) & (score<1 | score>upper | score!=floor(score))) ]
  d[bad_value | ett_value, score := NA_real_]
  # Identical scores collapse. Contradictory component values are not resolved by MIN/MAX.
  parts <- d[, {
    usable <- unique(score[!is.na(score)])
    conflict <- length(usable)>1L || (any(ett_value) && any(!ett_value)) || any(bad_value)
    list(score=if (!conflict && length(usable)==1L) usable else NA_real_,
         raw_text=paste(sort(unique(value[!is.na(value)])),collapse=' | '),
         n_raw=.N, conflict=conflict, ett=any(ett_value))
  },by=.(stay_id,charttime,component)]
  keys <- unique(parts[,.(stay_id,charttime)])
  for (part in c('eye','verbal','motor')) {
    z <- parts[component==part,.(stay_id,charttime,score,raw_text,n_raw,conflict)]
    data.table::setnames(z,c('score','raw_text','n_raw','conflict'),
                        c(part,paste0(part,'_raw_text'),paste0(part,'_n_raw'),paste0(part,'_conflict')))
    keys <- merge(keys,z,by=c('stay_id','charttime'),all.x=TRUE,sort=FALSE)
  }
  e <- parts[component=='verbal',.(stay_id,charttime,ett)]
  keys <- merge(keys,e,by=c('stay_id','charttime'),all.x=TRUE,sort=FALSE)
  keys[is.na(ett),ett:=FALSE]
  for (col in paste0(c('eye','verbal','motor'),'_conflict')) data.table::set(keys,which(is.na(keys[[col]])),col,FALSE)
  keys[, verbal_raw := verbal]
  keys[, verbal_imputed := ett & !verbal_conflict & !is.na(eye) & !is.na(motor)]
  keys[verbal_imputed==TRUE,verbal:=pmin(5,pmax(1,round_half_up(-0.3756+0.5713*motor+0.4233*eye)))]
  keys[, gcs_total_all := eye+verbal+motor]
  data.table::setorder(keys,stay_id,charttime)
  keys[]
}

annotate_gcs <- function(assessments, rass, sedatives) {
  x <- data.table::as.data.table(data.table::copy(assessments))
  x[, row_key := .I]
  x[, `:=`(rass_nearby=NA_real_,rass_charttime=as.POSIXct(NA,tz='UTC'),
           rass_conflict=FALSE,sedative_running=FALSE)]
  r <- data.table::as.data.table(data.table::copy(rass))
  if (nrow(r)) {
    r[, charttime := as_study_time(charttime)]
    r <- r[!is.na(valuenum) & valuenum>=-5 & valuenum<=4 & valuenum==floor(valuenum)]
    if (nrow(r)) {
      r <- r[,.(rass_value=min(valuenum),rass_conflict=data.table::uniqueN(valuenum)>1L),by=.(stay_id,charttime)]
      r[, matched_time := charttime]
      data.table::setkey(r,stay_id,charttime)
      prior <- r[x[,.(stay_id,charttime)],roll=Inf]
      after <- r[x[,.(stay_id,charttime)],roll=-Inf]
      dp <- abs(as.numeric(difftime(x$charttime,prior$matched_time,units='secs')))
      dn <- abs(as.numeric(difftime(x$charttime,after$matched_time,units='secs')))
      dp[is.na(dp)]<-Inf; dn[is.na(dn)]<-Inf
      use_prior <- dp<=dn
      vals <- ifelse(use_prior,prior$rass_value,after$rass_value)
      times <- prior$matched_time; times[!use_prior]<-after$matched_time[!use_prior]
      conflicts <- ifelse(use_prior,prior$rass_conflict,after$rass_conflict)
      keep <- pmin(dp,dn)<=7200
      x[keep, `:=`(rass_nearby=vals[keep],rass_charttime=times[keep],rass_conflict=conflicts[keep])]
    }
  }
  s <- data.table::as.data.table(data.table::copy(sedatives))
  if (nrow(s)) {
    s[, `:=`(starttime=as_study_time(starttime),endtime=as_study_time(endtime))]
    s <- s[!is.na(starttime) & !is.na(endtime) & endtime>starttime]
    if (nrow(s)) {
      x[, lookback := charttime-14400]
      ix <- s[x,on=.(stay_id,starttime<=charttime,endtime>=lookback),which=TRUE,mult='first']
      x[,sedative_running:=!is.na(ix)]
      x[,lookback:=NULL]
    }
  }
  x[, assessment_usable := ifelse(!is.na(rass_nearby),rass_nearby>=-2,!sedative_running)]
  x[, valid := assessment_usable & !is.na(gcs_total_all)]
  x[, valid_motor := assessment_usable & !is.na(motor)]
  x[, `:=`(gcs_total=ifelse(valid,gcs_total_all,NA_real_),
           gcs_motor=ifelse(valid_motor,motor,NA_real_),gcs_motor_all=motor)]
  x[, valid_reason := data.table::fcase(
    !is.na(rass_nearby) & rass_nearby< -2,'deep_rass',
    is.na(rass_nearby) & sedative_running,'no_rass_recent_infusion',
    is.na(gcs_total_all),'incomplete_or_conflicting_components',
    !is.na(rass_nearby),'rass_at_least_minus2',default='no_rass_no_recent_infusion')]
  x[,rass_delta_minutes:=as.numeric(difftime(rass_charttime,charttime,units='mins'))]
  x[,row_key:=NULL]
  data.table::setorder(x,stay_id,charttime)
  x[]
}

prepare_sedatives <- function(raw) {
  s<-data.table::as.data.table(data.table::copy(raw))
  s[,`:=`(starttime=as_study_time(starttime),endtime=as_study_time(endtime))]
  s[,actual_continuous:=!is.na(rate) & rate>0 & !is.na(amount) & amount>0 &
      !is.na(ordercategorydescription) & grepl('continuous',ordercategorydescription,ignore.case=TRUE) &
      (is.na(statusdescription) | tolower(statusdescription)!='rewritten')]
  bad<-s[actual_continuous==TRUE & (is.na(starttime)|is.na(endtime)|endtime<=starttime),.N]
  if (bad>0L) stop('Positive-dose continuous infusions with invalid intervals: ',bad)
  s[,include_infusion:=actual_continuous & !is.na(starttime) & !is.na(endtime) & endtime>starttime]
  s[]
}
