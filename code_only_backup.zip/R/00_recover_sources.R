# Regenerate source dependencies only. No final cohorts or trajectory labels.
source('R/00_setup.R')
source(here::here('R/bq_helpers.R'))
source(here::here('R/recovery_helpers.R'))
refresh <- '--refresh' %in% commandArgs(trailingOnly=TRUE)
queries <- sort(list.files(here::here('sql'),pattern='^00r_.*[.]sql$'))
summary <- list()
for (f in queries) {
 name <- sub('[.]sql$','',f)
 d <- query_to_cache(f,name,refresh)
 key <- switch(name, '00r_eicu_neuro_raw'='nursingchartid','00r_eicu_patient'='patientunitstayid',
  '00r_eicu_sedatives_raw'='infusiondrugid','00r_mimic_admission_death'='stay_id',NULL)
 if (!is.null(key) && (!key %in% names(d) || anyNA(d[[key]]) || anyDuplicated(d[[key]]))) stop('Invalid source primary key: ',name)
 summary[[name]] <- data.table(query=name,n_rows=nrow(d),n_columns=ncol(d))
 if (name=='00r_mimic_sepsis_sofa') {
  d <- annotate_sofa(d)
  stopifnot(all(is.na(d$sofa_without_cns) | d$sofa_without_cns>=0))
  fwrite(d,here::here('data/sepsis_sofa_source.csv.gz'),dateTimeAs='ISO')
 }
 if (name=='00r_mimic_admission_death') {
  stopifnot(!anyDuplicated(d$stay_id))
  d <- audit_stay_boundaries(d)
  fwrite(d[boundary_status!='usable'],here::here('data/audit/icu_boundary_exceptions.csv'),dateTimeAs='ISO')
  fwrite(d[,.(n_stays=.N),by=boundary_status],here::here('output/tables/icu_boundary_audit.csv'))
 }
 if (name=='00r_eicu_patient') stopifnot(!anyDuplicated(d$patientunitstayid))
 if (name=='00r_eicu_neuro_dictionary') fwrite(d,here::here('output/tables/eicu_neuro_dictionary.csv'))
 fwrite(rbindlist(summary),here::here('output/tables/recovered_source_counts.csv'))
 rm(d);gc()
}
message('Source recovery finished. These are raw dependencies, not final research cohorts.')
