source('R/00_setup.R')
# Exact runnable 2-class example from the installed Jointlcmm help page.
# Uses the package example data only, never project patient data.
set.seed(20261109)
started <- Sys.time()
example('Jointlcmm',package='lcmm',ask=FALSE,echo=TRUE,run.dontrun=FALSE)
stopifnot(inherits(m2,'Jointlcmm'),m2$conv==1L,is.finite(m2$loglik))
fwrite(data.table(package=as.character(packageVersion('lcmm')),example='Jointlcmm official m2',
  conv=m2$conv,loglik=m2$loglik,elapsed_seconds=as.numeric(difftime(Sys.time(),started,units='secs'))),
  here::here('output/tables/lcmm_smoke_result.csv'))
saveRDS(m2,here::here('models/lcmm_official_example_m2.rds'))
