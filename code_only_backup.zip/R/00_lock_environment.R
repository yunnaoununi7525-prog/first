source('R/00_setup.R')
options(repos=c(CRAN='https://cloud.r-project.org'))
# Capture exactly the runtime and its dependency closure; do not activate or alter global libraries.
renv::snapshot(project=project_root,library=.libPaths(),packages=required_packages,prompt=FALSE,force=TRUE)
