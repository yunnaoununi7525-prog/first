validate_cache_metadata <- function(meta, sql_hash) {
 if (!identical(meta$sql_sha256,sql_hash)) stop('Cache SQL signature mismatch; use --refresh')
 if (!identical(meta$bigint,'integer64')) stop('Cache predates lossless integer64 format; use --refresh')
 invisible(TRUE)
}

authenticate_bq <- function() {
  if (!nzchar(settings$billing_project)) stop('Set billing_project in config/settings.local.R')
  if (!bigrquery::bq_has_token()) {
    email <- if (nzchar(settings$bq_email)) settings$bq_email else TRUE
    bigrquery::bq_auth(email=email)
  }
}

query_to_cache <- function(sql_file, cache_name, refresh=FALSE) {
  sql_path <- here::here('sql',sql_file)
  sql <- paste(readLines(sql_path,warn=FALSE),collapse='\n')
  sql_hash <- digest::digest(sql,algo='sha256',serialize=FALSE)
  cache <- here::here('data/raw',paste0(cache_name,'.csv.gz'))
  meta_path <- here::here('output/provenance',paste0(cache_name,'.json'))
  if (file.exists(cache) && !refresh) {
    if (!file.exists(meta_path)) stop('Missing cache provenance; use --refresh: ',cache_name)
    validate_cache_metadata(jsonlite::read_json(meta_path),sql_hash)
    message('Read cached ',cache_name)
    return(data.table::fread(cache))
  }
  authenticate_bq()
  # Official jobs.insert dry-run API: validate schema and record scan estimate before billing.
  response <- httr::POST(
    paste0('https://bigquery.googleapis.com/bigquery/v2/projects/',settings$billing_project,'/jobs'),
    bigrquery::bq_token(),encode='json',
    body=list(configuration=list(dryRun=TRUE,query=list(query=sql,useLegacySql=FALSE))))
  httr::stop_for_status(response)
  dry <- httr::content(response,as='parsed',type='application/json')
  if (!is.null(dry$status$errorResult)) stop(dry$status$errorResult$message)
  bytes <- as.numeric(dry$statistics$totalBytesProcessed)
  if (length(bytes)!=1L || is.na(bytes)) stop('Dry run returned no byte estimate')
  message(cache_name,': dry-run scan ',round(bytes/1024^3,3),' GiB')
  if (bytes>settings$maximum_bytes_billed) stop('Query exceeds configured scan cap: ',cache_name)
  job <- bigrquery::bq_perform_query(sql,billing=settings$billing_project,
      configuration=list(query=list(maximumBytesBilled=format(settings$maximum_bytes_billed,scientific=FALSE,trim=TRUE))))
  bigrquery::bq_job_wait(job,quiet=TRUE)
  info <- bigrquery::bq_job_meta(job)
  tbl <- bigrquery::as_bq_table(info$configuration$query$destinationTable)
  message('Downloading ',cache_name,': ',bigrquery::bq_table_nrow(tbl),' rows')
  result <- data.table::as.data.table(bigrquery::bq_table_download(tbl,page_size=10000L,max_connections=4L,quiet=TRUE,bigint='integer64',api='json'))
  data.table::fwrite(result,cache,dateTimeAs='ISO',na='')
  jsonlite::write_json(list(sql_sha256=sql_hash,mimic_version=settings$mimic_version,
      eicu_version=settings$eicu_version,bigint='integer64',extraction_days=settings$extraction_days,rows=nrow(result),dry_run_bytes=bytes,
      queried_at=format(Sys.time(),tz='UTC',usetz=TRUE),job=info),meta_path,pretty=TRUE,auto_unbox=TRUE)
  log_path <- here::here('output/tables/query_jobs.csv')
  row <- data.table::data.table(query=cache_name,rows=nrow(result),dry_run_bytes=bytes,
    billed_bytes=as.numeric(info$statistics$query$totalBytesBilled),
    cache_hit=isTRUE(info$statistics$query$cacheHit),sql_sha256=sql_hash)
  data.table::fwrite(row,log_path,append=file.exists(log_path))
  result
}
