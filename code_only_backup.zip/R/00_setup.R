# Works from RStudio project root or Rscript /absolute/path/R/00_setup.R.
local({
  args <- commandArgs(trailingOnly=FALSE)
  farg <- args[grepl('^--file=',args)]
  root <- Sys.getenv('SAE_PROJECT_ROOT')
  if (!nzchar(root)) {
    if (length(farg) && basename(dirname(sub('^--file=','',farg[1]))) %in% c('R','tests')) {
      root <- dirname(dirname(normalizePath(sub('^--file=','',farg[1]))))
    } else {
      root <- getwd()
      while (!file.exists(file.path(root,'.here')) && dirname(root)!=root) root<-dirname(root)
    }
  }
  if (!file.exists(file.path(root,'.here'))) stop('Open the project or set SAE_PROJECT_ROOT')
  .libPaths(c(file.path(root,'.R-library'),.libPaths()))
  assign('project_root',normalizePath(root),envir=.GlobalEnv)
})
required_packages <- c('here','data.table','bigrquery','DBI','ggplot2','lcmm','survival','jsonlite','digest','renv','R.utils')
missing_packages <- required_packages[!vapply(required_packages,requireNamespace,logical(1),quietly=TRUE)]
if (length(missing_packages)) stop('Missing packages: ',paste(missing_packages,collapse=', '),'. Run tools/install_dependencies.R first.')
here::i_am('R/00_setup.R')
for (pkg in required_packages) suppressPackageStartupMessages(library(pkg,character.only=TRUE))
options(stringsAsFactors=FALSE,timeout=600)
Sys.setenv(TZ='UTC') # MIMIC shifted DATETIME values are kept as local clock values, without DST shifts.
data.table::setDTthreads(min(4L,parallel::detectCores()))
for (d in c('data/raw','data/audit','models','old','output/tables','output/figures','output/logs','output/provenance'))
  dir.create(here::here(d),recursive=TRUE,showWarnings=FALSE)
settings_file <- here::here('config/settings.local.R')
if (file.exists(settings_file)) source(settings_file) else source(here::here('config/settings.example.R'))
stopifnot(settings$mimic_version=='MIMIC-IV 3.1',settings$eicu_version=='eICU-CRD 2.0')
writeLines(c(paste('Captured',format(Sys.time(),tz='Asia/Hong_Kong',usetz=TRUE)),capture.output(sessionInfo())),here::here('output/session_info.txt'))
versions <- data.table(package=required_packages,version=vapply(required_packages,function(p)as.character(packageVersion(p)),character(1)))
fwrite(versions,here::here('output/tables/software_versions.csv'))
message('Setup OK. Database versions: ',settings$mimic_version,'; ',settings$eicu_version)
