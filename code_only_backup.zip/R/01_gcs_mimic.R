source('R/00_setup.R')
source(here::here('R/gcs_helpers.R'))
source(here::here('R/recovery_helpers.R'))
source(here::here('R/bq_helpers.R'))
args <- commandArgs(trailingOnly=TRUE)
refresh <- '--refresh' %in% args
writeLines('Step 1 running: raw extraction',here::here('output/logs/step01_status.txt'))
items <- query_to_cache('00_item_dictionary.sql','item_dictionary',refresh)
fwrite(items,here::here('output/tables/gcs_item_dictionary.csv'))
stopifnot(items[itemid==228096,grepl('Richmond',label)],
          all(c(220739L,223900L,223901L) %in% items$itemid))
for (drug in c('propofol','midazolam','dexmedetomidine','lorazepam'))
  if (!any(grepl(drug,tolower(items[linksto=='inputevents',label])))) stop('Missing drug dictionary match: ',drug)
stays <- query_to_cache('01_icu_stays.sql','icu_stays',refresh)
events <- query_to_cache('01_chartevents.sql','gcs_rass_events',refresh)
sed_raw <- query_to_cache('01_sedative_infusions.sql','sedative_infusions',refresh)
old <- query_to_cache('01_derived_old.sql','gcs_derived_old',refresh)
for (col in intersect(c('intime','outtime','extraction_end'),names(stays))) set(stays,j=col,value=as_study_time(stays[[col]]))
stays <- make_extraction_frame(stays)
fwrite(stays[,.(n_stays=.N),by=boundary_status],here::here('output/tables/icu_boundary_audit.csv'))
events[,charttime:=as_study_time(charttime)]
sed_raw[,`:=`(starttime=as_study_time(starttime),endtime=as_study_time(endtime))]
old[,charttime:=as_study_time(charttime)]
# Actual continuous medications only, preserving boluses and excluded records in raw cache.
sed_raw <- prepare_sedatives(sed_raw)
sed_audit <- sed_raw[,.(n_records=.N,n_eligible=sum(include_infusion),
                       n_nonpositive_amount=sum(is.na(amount)|amount<=0)),
                      by=.(label,ordercategorydescription,statusdescription)]
fwrite(sed_audit,here::here('output/tables/sedative_infusion_audit.csv'))
writeLines('Step 1 running: GCS reconstruction',here::here('output/logs/step01_status.txt'))
raw_gcs <- events[itemid!=228096L]
rass <- events[itemid==228096L,.(stay_id,charttime,valuenum)]
sed <- sed_raw[include_infusion==TRUE]
gcs <- annotate_gcs(build_gcs_assessments(raw_gcs),rass,sed)
if (old[,anyDuplicated(paste(stay_id,charttime))]>0L) stop('Old GCS has duplicate stay/time keys')
gcs <- merge(gcs,old,by=c('stay_id','charttime'),all.x=TRUE,sort=FALSE)
gcs <- merge(gcs,stays[,.(subject_id,hadm_id,stay_id,intime,outtime,extraction_end,boundary_status,coverage_eligible)],by='stay_id',all.x=TRUE,sort=FALSE)
gcs[,day:=floor(as.numeric(difftime(charttime,intime,units='days')))]
setorder(gcs,stay_id,charttime)
stopifnot(!anyDuplicated(gcs[,.(stay_id,charttime)]),all(gcs$day>=0 & gcs$day<14),
          all(is.na(gcs$gcs_total_all) | gcs$gcs_total_all %between% c(3,15)),
          all(is.na(gcs$gcs_total) | gcs$valid))
front <- c('stay_id','charttime','eye','verbal','motor','ett','verbal_imputed','rass_nearby',
           'sedative_running','valid','gcs_total','gcs_motor','gcs_total_all','gcs_derived_old')
setcolorder(gcs,c(front,setdiff(names(gcs),front)))
fwrite(gcs,here::here('data/gcs_long_mimic.csv'),dateTimeAs='ISO',na='')
# Patient-day coverage includes days without any component records.
stays[,n_days:=as.integer(ceiling(as.numeric(difftime(extraction_end,intime,units='days'))))]
frame <- stays[coverage_eligible==TRUE & n_days>0,.(day=seq_len(n_days)-1L),by=.(stay_id)]
pd <- gcs[,.(n_assess=.N,n_valid=sum(valid),n_motor_valid=sum(valid_motor)),by=.(stay_id,day)]
frame <- merge(frame,pd,by=c('stay_id','day'),all.x=TRUE)
frame[is.na(n_assess),`:=`(n_assess=0L,n_valid=0L,n_motor_valid=0L)]
coverage <- frame[,.(n_patient_days=.N,n_with_any_gcs=sum(n_assess>0),
                     n_with_valid_gcs=sum(n_valid>0),n_with_valid_motor=sum(n_motor_valid>0)),by=day]
coverage[,valid_gcs_pct:=100*n_with_valid_gcs/n_patient_days]
fwrite(coverage,here::here('output/tables/gcs_patient_day_coverage.csv'))
checks <- list()
add <- function(metric,n,denom,definition) {
 checks[[length(checks)+1L]] <<- data.table(metric=metric,n=as.numeric(n),denominator=as.numeric(denom),
                                         percent=if(denom>0)100*n/denom else NA_real_,definition=definition)
}
N<-nrow(gcs)
add('stays_missing_outtime',sum(stays$boundary_status=='missing_outtime'),nrow(stays),'Raw GCS retained through day14; unknown follow-up excluded from coverage denominator')
add('assessments_unknown_outtime',sum(gcs$boundary_status=='missing_outtime'),N,'GCS reconstructed from stay-linked raw records; discharge time remains unknown')
add('ett_assessments',sum(gcs$ett),N,'Verbal raw text No Response-ETT')
add('verbal_imputed',sum(gcs$verbal_imputed),N,'ETT with eye and motor available, no verbal conflict')
add('eye_missing',sum(is.na(gcs$eye)),N,'Missing or conflicting eye component')
add('verbal_missing_after_imputation',sum(is.na(gcs$verbal)),N,'Missing verbal after ETT correction')
add('motor_missing',sum(is.na(gcs$motor)),N,'Missing or conflicting motor component')
add('component_conflict',sum(gcs$eye_conflict|gcs$verbal_conflict|gcs$motor_conflict),N,'Any contradictory or invalid component')
add('valid_assessments',sum(gcs$valid),N,'Complete total and sedation/RASS rule passed')
add('valid_motor_assessments',sum(gcs$valid_motor),N,'Motor present and sedation/RASS rule passed')
add('rass_nearby',sum(!is.na(gcs$rass_nearby)),N,'Usable RASS within closed ±2h window')
add('sedative_recent_overlap',sum(gcs$sedative_running),N,'Eligible infusion overlaps closed preceding four hours')
old15 <- !is.na(gcs$gcs_derived_old)&gcs$gcs_derived_old==15
add('old15_corrected_lower_all',sum(old15 & !is.na(gcs$gcs_total_all)&gcs$gcs_total_all<15),sum(old15),'Old 15 becoming lower among all reconstructed totals')
add('old15_corrected_lower_valid',sum(old15 & !is.na(gcs$gcs_total)&gcs$gcs_total<15),sum(old15),'Old 15 becoming lower in valid primary totals')
add('old15_complete_comparison',sum(old15 & !is.na(gcs$gcs_total_all)),sum(old15),'Old15 records with a complete reconstructed total')
add('patient_days_with_valid_gcs',sum(frame$n_valid>0),nrow(frame),'Known-discharge extraction-frame patient-days, including no-GCS days; unknown end excluded from this denominator')
add('stays_with_valid_gcs',uniqueN(gcs[valid==TRUE,stay_id]),nrow(stays),'All ICU stays, before step-2 cohort selection')
qc <- rbindlist(checks);fwrite(qc,here::here('output/tables/gcs_fix_check.csv'))
reason <- gcs[,.(n=.N),by=valid_reason];reason[,percent:=100*n/sum(n)]
fwrite(reason,here::here('output/tables/gcs_validity_reasons.csv'))
# Distribution counts avoid copying millions of rows into ggplot.
counts <- rbindlist(list(gcs[!is.na(gcs_derived_old),.(n=.N),by=.(gcs=gcs_derived_old)][,version:='Old derived'],
                         gcs[!is.na(gcs_total_all),.(n=.N),by=.(gcs=gcs_total_all)][,version:='Reconstructed all'],
                         gcs[valid==TRUE,.(n=.N),by=.(gcs=gcs_total)][,version:='Reconstructed valid']))
counts[,percent:=100*n/sum(n),by=version]
fwrite(counts,here::here('output/tables/gcs_distribution_counts.csv'))
p<-ggplot(counts,aes(gcs,percent,fill=version))+geom_col(width=.8)+
 facet_wrap(~version,ncol=1)+scale_x_continuous(breaks=3:15)+
 scale_fill_manual(values=c('Old derived'='#7F8C8D','Reconstructed all'='#3498DB','Reconstructed valid'='#117864'))+
 labs(x='GCS total',y='Assessments (%)',title='MIMIC-IV 3.1 GCS reconstruction',
      subtitle='All ICU stays; first 14 days; before early-sepsis cohort selection')+
 theme_minimal(base_size=12)+theme(legend.position='none',panel.grid.minor=element_blank())
ggsave(here::here('output/figures/gcs_old_vs_new.png'),p,width=8,height=9,dpi=180)
# Random 20 subjects; one auditable assessment each, prioritising ETT if present.
set.seed(settings$audit_seed)
subjects <- sort(unique(gcs$subject_id))
sample_path <- here::here('data/audit/initial_random20_subject_ids.json')
if (file.exists(sample_path)) {
 sample_ids <- as.numeric(jsonlite::read_json(sample_path,simplifyVector=TRUE))
 stopifnot(length(sample_ids)==20L,!anyDuplicated(sample_ids),all(sample_ids %in% subjects))
} else {
 sample_ids <- sample(subjects,min(20L,length(subjects)))
 jsonlite::write_json(as.character(sample_ids),sample_path)
}
audit <- gcs[subject_id %in% sample_ids]
setorder(audit,subject_id,-ett,charttime)
review <- audit[,head(.SD,1L),by=subject_id]
review[,`:=`(review_status='pending_independent_source_check',review_notes='')]
fwrite(review,here::here('output/tables/gcs_manual_review_20.csv'),dateTimeAs='ISO')
fwrite(raw_gcs[subject_id %in% sample_ids],here::here('data/audit/raw_gcs_20_subjects.csv.gz'),dateTimeAs='ISO')
fwrite(events[subject_id %in% sample_ids & itemid==228096L],here::here('data/audit/raw_rass_20_subjects.csv.gz'),dateTimeAs='ISO')
fwrite(sed_raw[subject_id %in% sample_ids],here::here('data/audit/raw_sedatives_20_subjects.csv.gz'),dateTimeAs='ISO')
fwrite(audit,here::here('data/audit/reconstructed_20_subjects.csv.gz'),dateTimeAs='ISO')
writeLines(c('Step 1 data extraction and reconstruction complete',
             paste('Assessments',N),paste('ICU stays with GCS',uniqueN(gcs$stay_id)),
             paste('Subjects with GCS',uniqueN(gcs$subject_id)),
             '20-subject independent source review must be checked separately'),here::here('output/logs/step01_status.txt'))
print(qc)
