# 早期脓毒症 GCS 轨迹项目

本目录是独立工作副本。桌面、Drive、GitHub main 和原论文工作区的源文件均保留。先阅读 [第0至1步交付说明](docs/completion_zh.md) 和 [文件筛选说明](docs/file_selection_zh.md)。

## 当前结果

第0步的项目环境已建立，第1步的真实 MIMIC-IV GCS 数据已提取、重建并核查。范围是全部 ICU 停留的前14天，尚未执行第2步的早期脓毒症队列筛选。

- GCS 评估总数：2,001,331。
- ETT 评估：670,263（33.49%）；成功估算言语分：665,401。
- 有效主版本评估：1,591,242（79.51%）。
- 旧15分被修正到低于15分：全部可计算评估 571,596 次；仅有效评估 244,389 次。
- 至少有一次有效 GCS 的患者日：299,086 / 350,667（85.29%）。患者日只对边界明确的停留按24小时窗计；14次出ICU时间缺失的停留不进入这个分母，但其593次原始GCS评估已保留并标记。

## 运行顺序

在本目录打开 gcs_early_sepsis.Rproj，或先在终端进入本目录。代码通过 here 定位文件，不读取旧桌面路径。

```sh
Rscript --vanilla tools/install_dependencies.R
Rscript --vanilla R/00_setup.R
Rscript --vanilla R/00_lcmm_smoke.R
Rscript --vanilla tests/run_tests.R
Rscript --vanilla R/00_recover_sources.R
Rscript --vanilla tests/test_recovery.R
Rscript --vanilla tests/verify_recovered_sources.R
Rscript --vanilla R/01_gcs_mimic.R
python3 tools/verify_20_subjects.py
Rscript --vanilla tests/verify_real_outputs.R
python3 tools/audit_sources.py
```

本机已有私人配置。换电脑时复制 config/settings.example.R 为 config/settings.local.R，填入自己的 billing_project 和授权邮箱；登录在本人浏览器完成。不要把配置、患者数据或 old/ 归档提交 Git。已有同一 SQL 的 data/raw 缓存可离线重建；只有明确使用 --refresh 才重新查询；SQL签名不符或不具备integer64格式标记的旧缓存会被拒绝。每次查询先做 dry-run 并限制扫描量为100 GiB，查询元数据保存在 output/provenance/。

renv.lock 和 output/session_info.txt 保存实际环境。若恢复锁定环境，先安装 renv，再在项目根目录运行 renv::restore(library='.R-library',prompt=FALSE)。本项目不通过自动启动钩子改变系统 R 库。

## 脚本接口

| 脚本 | 输入 | 输出 |
|---|---|---|
| R/00_setup.R | 私人设置与项目包 | output/session_info.txt、software_versions.csv |
| R/00_lock_environment.R | 当前依赖版本 | renv.lock |
| R/00_lcmm_smoke.R | lcmm 自带示例数据 | lcmm_smoke_result.csv、模型及日志 |
| R/00_recover_sources.R | sql/00r_* 与私人BigQuery配置 | eICU原始神经/镇静记录、MIMIC CAM/药物医嘱/SOFA/住院死亡源表及审计；不是最终队列 |
| R/recovery_helpers.R | ICU边界、SOFA、提取清单 | 边界标记、去CNS分数、完整性检查 |
| R/01_gcs_mimic.R | sql/ 查询或签名匹配的 data/raw 缓存 | data/gcs_long_mimic.csv、GCS检查表、分布图、20人抽样材料 |
| R/gcs_helpers.R | 原始分项、RASS、输注区间 | 无副作用的重建与有效性函数 |
| R/bq_helpers.R | SQL、私人 BigQuery 配置 | 受查询上限保护的原始缓存与元数据 |
| tools/verify_20_subjects.py | 20人抽样的原始记录和重建结果 | 独立复算的核查表和日志 |
| tools/audit_sources.py | 来源副本和清单 | 旧CSV行列检查、云地版本比较、原件完整性检查 |

## GCS 修正方法

从 MIMIC-IV 3.1 chartevents 提取睁眼、言语、运动分项，以 stay_id 和 charttime 合并，保留原始文字及缺失情况，不以前值或正常值补齐缺失分项。言语文字为 No Response-ETT 时，按工作计划的 Meredith 公式估算言语分，四舍五入并限制为1至5分，同时保留估算标记。取评估前后2小时内时间最近的有效 RASS，等距时优先取评估前值；RASS ≥ −2时可用，若无有效 RASS，则要求评估前4小时无持续镇静输注重叠。保存有效总分、运动分、全部评估总分及原来的衍生 GCS 四个版本；缺失或无效的主版本总分保持缺失。

## 数据字段

gcs_total：有效、完整评估的总分；gcs_total_all：不按镇静筛除的完整总分；gcs_motor：通过镇静规则的运动分；gcs_motor_all：全部运动分；gcs_derived_old：精确相同时间的旧衍生总分。
valid：完整总分且通过镇静规则；valid_motor：运动分可用且通过镇静规则。rass_nearby 是所选 RASS 数值，rass_charttime 和 rass_delta_minutes 保存时间依据；sedative_running 表示前4小时任一实际持续输注重叠，并非只检查评估瞬间。eye/verbal/motor 是重建后分项，verbal_raw 与 *_raw_text、*_n_raw、*_conflict 保存来源证据。

## 来源与待办

数据库版本：MIMIC-IV 3.1；eICU-CRD 2.0（本次未新建eICU队列）。GitHub来源固定于683f1d3a9ed4ca079abc360ce56fc8f382a8e86d。计算地点：本机笔记本；未确认实验室服务器。

已重新检索三个来源并补建可重跑的原始提取脚本；旧最终CSV和旧轨迹分类的完整历史生成链仍不可证明，见 docs/file_selection_zh.md。20人已独立程序复算并由AI逐例阅读原始证据，人工签核仍待完成，见 docs/gcs_review_status_zh.md。工作计划要求的组会展示由研究团队安排。代码版本保存在本项目 Git 分支，远程发布情况见 docs/completion_zh.md。

## GitHub代码备份

上一版两份授权文件已上传至 [codex/gcs-steps0-1](https://github.com/yunnaoununi7525-prog/first/tree/codex/gcs-steps0-1)，远程提交 eee7636。上一版上传后逐字节核对通过，main保持原提交683f1d3。本轮补查修复以本地Git版本为准，尚未更新远程快照。下载code_only_backup.zip并解压可恢复代码目录结构；患者级数据仅保存在本地。

## 本轮验收边界

核对详情见 docs/recovery_report_zh.md。boundary_status 和 coverage_eligible 明确区分未知出ICU时间；outtime保持缺失，不用住院死亡日期推造精确时间。eICU护士记录编号以64位整数保存。原始药物医嘱不是实际给药证明，也不能单独诊断谵妄；eICU镇静目标分数、SAS和RASS不能混为同一评分。
