# Progress ledger for step00_01_plan.md

- Source snapshot: initial 153 files inventoried; local originals retained in place.
- Task setup: R 4.5.3; lcmm 2.2.2 already installed; here, rprojroot and renv installed in project-private .R-library only.
- Authentication: existing cached account selected; BigQuery SELECT 1 succeeded without a new credential grant.
- GCS tests: RED before gcs_helpers.R existed; 23 behavioural assertions passed after implementation.
- Compatibility ruling: bigrquery::bq_job_table is internal in this version; use exported bq_job_meta + as_bq_table instead.
- Extraction: running on all ICU stays, first 14 days, no historical SAE or GCS selection.
- Source gaps: documented in file_selection_zh.md. They do not block raw GCS reconstruction.

- Task setup: complete. Fresh R setup passed; renv.lock generated. Official Jointlcmm example conv=1, loglik=-3921.28129972051.
- Task raw GCS: complete. 7,443,018 GCS/RASS events and 743,784 sedative input records downloaded; 2,000,738 reconstructed assessments, 1,591,050 valid.
- Task verification: 26 helper assertions, full real-output acceptance and independent Python recomputation of 20 randomly sampled subjects passed.
- Source integrity: 132 original local files unchanged; 161 source entries and 53 CSV audits; six cloud CSVs byte-identical to desktop versions.
- Independent code review: no critical or important issues reported. Output distribution figure visually inspected, no clipping/overlap.
- Outstanding: unavailable historical generator scripts, clinical/team review, group meeting and remote GitHub publication are not claimed complete.
- Remote backup: command-line GitHub credentials unavailable; browser public upload rejected by automatic approval review. Explicit authorization for code_only_backup.zip and README_GCS_steps0_1.md to public yunnaoununi7525-prog/first branch codex/gcs-steps0-1 requested. No remote upload occurred.
- Remote backup now complete after explicit user authorization and browser permission setup: commit eee7636 on codex/gcs-steps0-1; exactly two authorized files uploaded and SHA256 matched. main verified unchanged at 683f1d3.

## 2026-11-09 第二轮补查

见source_recovery_plan.md与recovery_report_zh.md。发现并修复64位eICU编号溢出、未知出院时间遗漏和部分清单误验收；保留旧源不可恢复与人工签核未完成状态。
