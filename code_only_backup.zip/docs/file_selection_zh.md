# 文件筛选与复用说明

本项目依据《工作计划 GCS轨迹 早期脓毒症 中文版》执行第 0、1 步。原件保持原位；old/ 是隔离副本，不是新分析的输入目录。逐文件来源、校验值和用途见 output/tables/source_manifest.csv；旧 CSV 的完整行列核对见 local_csv_audit.csv。

| 文件或材料 | 本次处理 | 可复用的部分与限制 |
|---|---|---|
| 修改版2.3 | 部分复用并归档 | BigQuery 连接、表名、化验查询思路；旧 SAE/GCS 筛选、缺失处理、时间窗和桌面依赖不能沿用 |
| 2.5 add_sae_requirement_variables.R | 部分复用并归档 | 脓毒症时间取 culture_time 与 sofa_time 的较晚值及单项缺失回退逻辑，供第2步审查；该版本只删除 SOFA 分项列名，没有重新查询这些分项 |
| ICD/ 编码与查询 | 后续临床核对后复用 | 排除编码是可编辑的代码/参考表，须先由临床核对，尚未用于新队列 |
| SAE_analysis.Rmd | 部分复用并归档 | 缺失检查和绘图思路；不能直接执行旧的样本筛选与危险因素结果 |
| make_eicu_hospital_missing_filter_table1.R | 第6步修改后复用 | 医院缺失检查、汇总表；须换成新队列、新 GCS 与相对路径 |
| 整理表格2.4 | 替换 | 使用旧 derived.gcs 和小时最低值，不能恢复 GCS 三分项或输注时间 |
| 画图、gcs_latent_trajectory_plots.R | 历史探索 | flexmix 与1000人抽样不满足新设计；可参考作图但不沿用类别 |
| 模型、三个模型 | 第7步参考 | ROC、SHAP 和模型接口；旧特征、切点和结局评估不能作为新结果 |
| SAE_prediction.Rmd | 历史方案 | 已被新设计取代 |
| Drive 05_fit_crlcmm (1).R | 第4步参考 | 使用 sepsis_time 起点及镇静协变量；与当前中文版计划不一致，不能直接运行作为主模型 |
| Drive 三份方案文档 | 设计依据与冲突核对 | execution_protocol、design_review、PlanB_prime 均已保存文本副本；本任务以中文版工作计划为准 |
| df_teacher 各版、df_sepsis3 各版、轨迹类别 CSV | 旧数据对照 | 可检查旧行列和追溯结果，不能代替原始分项、RASS 和输注区间，也不能用来筛新队列 |
| eICU 已导出 CSV 和医院表 | 第6步历史对照 | 不在本次重建 MIMIC GCS 时合并 |
| publication_ready、论文草稿、k=2/3 图 | 历史文稿与图 | 原结果不代表新方案已经执行，不作为当前结果复用 |
| 参考论文 PDF 和补充 DOCX | 方法参考 | 归档，不改写，不计作本研究结果 |
| 会议录像、CITI证书、Word锁文件 | 本次无需修改 | 不复制大型录像和证书；保留原处，不删除 |

## 重新检索后的结论（2026-11-09）

GitHub账户只有first仓库；检查了两分支、全部25次提交与27个唯一内容对象。用户已确认所指eICU代码就是make_eicu_hospital_missing_filter_table1.R：该脚本已找到并保存，它读取现成CSV并筛医院/生成表1，不包含原始数据库提取。

| 原缺口 | 当前处理 | 是否可声称恢复原版 |
|---|---|---|
| eICU上游提取 | 新增00_recover_sources.R及00r_eicu_*查询；生成patient、原始护理评分、镇静输注观测、标签取值字典 | 否；是新建原始提取层，不是旧CSV完整生成器。第6步定义及队列仍待执行 |
| cam_icu.csv查询 | 从d_items查实13个相关项目，重新提取原始文字、数值与时间 | 否；没有臆造旧CAM导出规则。原始不同代际特征、UTA和直接评估保留，临床解释不在本轮偷作决定 |
| delirium_drug.csv查询 | 提取旧脚本药名模式涉及的医嘱，明确区分antipsychotic_order与sedative_order；持续镇静另从inputevents提取 | 否；医嘱不等于实际给药，镇静药不等于谵妄治疗，不伪造旧rate字段 |
| ...complete_death_outcomes.csv生成器 | 重新提取ICU/住院/患者/死亡时间源表和sepsis3含SOFA六分项 | 否；旧队列筛选、旧化验窗和死亡日期处理不能冒充新方案，新的队列/基线分别属第2–3步 |
| ...7d_y12...类别生成器 | 相关flexmix代码保留归档，历史最终参数/种子不可证明 | 否；原始数据库不能还原未知随机拟合。新类别按第4步生成，本轮不提前拟合 |
| SOFA分项 | 已从真实sepsis3表提取六分项，并生成去CNS分数和是否依赖CNS达阈值的标记 | 新源表已生成；未做早期脓毒症队列选择 |

Drive根目录、方法代码与论文子目录、本地sae及代码引用的旧Codex路径均复查；没有发现上述历史生成器。当前项目的新GCS流程不依赖这些不可追溯旧最终CSV；新原始来源和SQL已保存，可重复运行。原始文件未修改。
