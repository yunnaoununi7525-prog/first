# Execution decisions

- User confirmed: preserve all original files; project lives in Desktop/工作/sae/gcs_early_sepsis_20261109.
- User confirmed: nearest RASS within ±2 hours; ties prefer the assessment before GCS.
- User confirmed: existing BigQuery access; local laptop only.
- Ruling: Chinese work plan governs this task. Older cloud execution protocol and 05_fit_crlcmm.R retain sedated GCS and sepsis-anchored bins; those choices conflict with this work plan and are not used in step 1.
- Ruling: extract all ICU stays for the first 14 days, without old SAE, GCS, sepsis or duration exclusions. Step 2 will define the new analytic cohort. Timestamps at the 14-day endpoint are excluded.
- Ruling: no component carry-forward and no default-to-normal. Duplicate equal scores collapse; contradictory numeric values, ETT/non-ETT verbal conflicts and impossible values make that component missing. Original event rows remain in data/raw.
- Ruling: study time is represented as UTC solely to preserve deidentified DATETIME clock arithmetic; this is not an assertion about the hospital timezone.
- Ruling: sedative_running means overlap with the closed interval [GCS−4h,GCS], rather than only infusions starting in that interval. RASS takes precedence where available.
- Ruling: duplicate conflicting RASS at exactly the same time uses the lower value and is flagged for audit.
- Ruling: GCS motor-only sensitivity is usable when motor and sedation criteria are available even if eye/verbal are missing; valid_motor records this separately.
- Ruling: use a project-private R package library and a renv lockfile; leave system R packages unchanged.
- Ruling: source archives may contain patient summaries and private project identifiers, so old/ is Git-ignored in full. Only reviewed code and aggregate outputs can be committed.

- Ruling: four continuous-med inputevents rows had zero or negative amount and zero/negative duration. Exclude nonpositive amount, nonpositive rate, drug pushes and rewritten records. Positive-dose continuous records with invalid intervals fail loudly.
