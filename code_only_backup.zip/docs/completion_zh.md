# 第0至1步当前交付状态

本轮重新检索并修复后，第1步主数据为2,001,331次评估，其中1,591,242次有效。详细证据、修复和仍未关闭事项见[补查与修复报告](recovery_report_zh.md)。第2步尚未开始。

已具备：独立项目、固定环境/数据库版本、官方lcmm示例、可重跑原始提取、新GCS长表、数量/覆盖率/分布图、独立复算和AI逐例源记录检查。新增eICU原始提取、MIMIC CAM/药物医嘱/SOFA/住院死亡来源。

尚不能声称全部完成：历史最终生成链不可恢复；人工20人签核和组会展示未完成。新原始提取层不能冒充旧完整研究数据生成器。详见[file_selection_zh.md](file_selection_zh.md)及[gcs_review_status_zh.md](gcs_review_status_zh.md)。

本地项目为桌面指定的独立目录。原有桌面、Drive与GitHub main文件不改动。患者数据、模型、私人配置、抽样患者记录不上传。

GitHub上一版代码压缩包位于[codex/gcs-steps0-1](https://github.com/yunnaoununi7525-prog/first/tree/codex/gcs-steps0-1)，提交eee7636；本轮修改尚未更新该远程快照。main原提交683f1d3保持不变。
