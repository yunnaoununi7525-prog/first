# Steps 0 and 1 execution plan

Goal: isolated, reproducible setup and corrected raw GCS reconstruction, with original sources preserved.

1. Snapshot and classify local, GitHub and shared Drive sources; preserve checksums and provenance.
2. Configure project-private dependencies, here paths, private BigQuery settings, pinned database versions; run official Jointlcmm example.
3. Reconstruct exact-time GCS components, ETT verbal imputation, nearest RASS and overlapping sedative infusions; retain all four GCS versions.
4. Extract real data with dry-run scan estimates and query caps, generate quality tables and distribution figure; independently check 20 subjects.
5. Verify original integrity, run tests, review code and save honest completion states.

Constraints: no original file edits, no old cohort restriction, no patient data or credentials in Git. Chinese work plan is the source specification; RASS nearest/tie policy was chosen by the user.
