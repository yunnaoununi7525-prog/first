from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parents[1]
with (ROOT/'output/tables/gcs_fix_check.csv').open() as f:q={x['metric']:x for x in csv.DictReader(f)}
def n(k):return f"{int(float(q[k]['n'])):,}"
def pct(k):return f"{float(q[k]['percent']):.2f}%"
readme=f'''# 早期脓毒症 GCS 轨迹项目

本目录是独立工作副本。桌面、Drive、GitHub main 和原论文工作区的源文件均保留。先阅读 [第0至1步交付说明](docs/completion_zh.md) 和 [文件筛选说明](docs/file_selection_zh.md)。

## 当前结果

第0步的项目环境已建立，第1步的真实 MIMIC-IV GCS 数据已提取、重建并核查。范围是全部 ICU 停留的前14天，尚未执行第2步的早期脓毒症队列筛选。

- GCS 评估总数：{int(float(q['ett_assessments']['denominator'])):,}。
- ETT 评估：{n('ett_assessments')}（{pct('ett_assessments')}）；成功估算言语分：{n('verbal_imputed')}。
- 有效主版本评估：{n('valid_assessments')}（{pct('valid_assessments')}）。
- 旧15分被修正到低于15分：全部可计算评估 {n('old15_corrected_lower_all')} 次；仅有效评估 {n('old15_corrected_lower_valid')} 次。
- 至少有一次有效 GCS 的患者日：{n('patient_days_with_valid_gcs')} / {int(float(q['patient_days_with_valid_gcs']['denominator'])):,}（{pct('patient_days_with_valid_gcs')}）。患者日以住ICU期间的24小时窗计，不补齐出ICU后的日期。

## 运行顺序

在本目录打开 gcs_early_sepsis.Rproj，或先在终端进入本目录。代码通过 here 定位文件，不读取旧桌面路径。

```sh
Rscript --vanilla tools/install_dependencies.R
Rscript --vanilla R/00_setup.R
Rscript --vanilla R/00_lcmm_smoke.R
Rscript --vanilla tests/run_tests.R
Rscript --vanilla R/01_gcs_mimic.R
python3 tools/verify_20_subjects.py
Rscript --vanilla tests/verify_real_outputs.R
python3 tools/audit_sources.py
```

本机已有私人配置。换电脑时复制 config/settings.example.R 为 config/settings.local.R，填入自己的 billing_project 和授权邮箱；登录在本人浏览器完成。不要把配置、患者数据或 old/ 归档提交 Git。已有同一 SQL 的 data/raw 缓存可离线重建；只有明确使用 --refresh 才重新查询。每次查询先做 dry-run 并限制扫描量为100 GiB，查询元数据保存在 output/provenance/。

renv.lock 和 output/session_info.txt 保存实际环境。若恢复锁定环境，先安装 renv，再在项目根目录运行 renv::restore(library='.R-library',prompt=FALSE)。本项目不通过自动启动钩子改变系统 R 库。

## 脚本接口

| 脚本 | 输入 | 输出 |
|---|---|---|
| R/00_setup.R | 私人设置与项目包 | output/session_info.txt、software_versions.csv |
| R/00_lock_environment.R | 当前依赖版本 | renv.lock |
| R/00_lcmm_smoke.R | lcmm 自带示例数据 | lcmm_smoke_result.csv、模型及日志 |
| R/01_gcs_mimic.R | sql/ 查询或签名匹配的 data/raw 缓存 | data/gcs_long_mimic.csv、GCS检查表、分布图、20人抽样材料 |
| R/gcs_helpers.R | 原始分项、RASS、输注区间 | 无副作用的重建与有效性函数 |
| R/bq_helpers.R | SQL、私人 BigQuery 配置 | 受查询上限保护的原始缓存与元数据 |
| tools/verify_20_subjects.py | 20人抽样的原始记录和重建结果 | 独立复算的核查表和日志 |
| tools/audit_sources.py | 来源副本和清单 | 旧CSV行列检查、云地版本比较、原件完整性检查 |

## GCS 修正方法

从 MIMIC-IV 3.1 chartevents 提取睁眼、言语、运动分项，以 stay_id 和 charttime 合并，保留原始文字及缺失情况，不以前值或正常值补齐缺失分项。言语文字为 No Response-ETT 时，按工作计划的 Meredith 公式估算言语分，四舍五入并限制为1至5分，同时保留估算标记。取评估前后2小时内时间最近的有效 RASS，等距时优先取评估前值；RASS ≥ −2时可用，若无有效 RASS，则要求评估前4小时无持续镇静输注重叠。保存有效总分、运动分、全部评估总分及原来的衍生 GCS 四个版本；缺失或无效的主版本总分保持缺失。

## 数据字段

gcs_total：有效、完整评估的总分；gcs_total_all：不按镇静筛除的完整总分；gcs_motor：通过镇静规则的运动分；gcs_motor_all：全部运动分；gcs_derived_old：精确相同时间的旧衍生总分。
valid：完整总分且通过镇静规则；valid_motor：运动分可用且通过镇静规则。rass_nearby 是所选 RASS 数值，rass_charttime 和 rass_delta_minutes 保存时间依据；sedative_running 表示前4小时任一实际持续输注重叠，并非只检查评估瞬间。eye/verbal/motor 是重建后分项，verbal_raw 与 *_raw_text、*_n_raw、*_conflict 保存来源证据。

## 来源与待办

数据库版本：MIMIC-IV 3.1；eICU-CRD 2.0（本次未新建eICU队列）。GitHub来源固定于683f1d3a9ed4ca079abc360ce56fc8f382a8e86d。计算地点：本机笔记本；未确认实验室服务器。

部分旧数据生成源码没有找到；清单见 docs/file_selection_zh.md。20人核查是独立程序对原始记录的逐例复算，不能写成临床医生核查。工作计划要求的组会展示由研究团队安排。代码版本保存在本项目 Git 分支，远程发布情况见 docs/completion_zh.md。
'''
(ROOT/'README.md').write_text(readme)
completion=f'''# 第0至1步交付说明

本次已经实际生成可打开的文件，而非仅有计划。首先查看 README.md 和 output/tables/gcs_fix_check.csv；患者级数据在 data/gcs_long_mimic.csv，约485 MB，不宜用 Excel 直接打开。

## 已完成

- 独立项目结构、私人配置、here 路径、固定数据库版本、依赖锁定文件及新 R 会话验证。
- 来源清单161项，53份旧CSV行列审计；132份本地源文件校验值保持不变。6份云端旧CSV与桌面副本逐字节一致。
- Jointlcmm 官方两类别示例收敛：conv=1，loglik约 −3921.2813，输出和日志均已保存。
- 从真实MIMIC提取分项、RASS和四种镇静药输注；形成2,000,738次评估的长表。有效评估 {n('valid_assessments')} 次。
- GCS修正数量、缺失情况、每日覆盖率、输注审计表和旧新分布图。
- 20名固定随机患者的原始记录独立复算全部通过；有完整证据文件，患者标识留在本地。
- 独立代码审查未发现关键或重要问题；完整输出验收结果见 output/logs/。

## 仍未完成或需研究团队处理

- 未找到部分历史数据的完整生成脚本。没有伪造来源，也没有把旧结果重新命名成新结果；具体文件及缺口已逐项记录。这些缺口不影响本次原始GCS重建，但第0步“补齐全部历史生成脚本”不能标记为已完成。
- 临床医生核对、每周组会展示尚未发生。20人检查属于程序独立复算，不代替临床复核。
- 目前只确认本机计算资源，未获得实验室服务器。
- GitHub远程未发布；本地独立分支保留了可追溯代码。原仓库main不变。
- 第2步及以后未执行；上述样本量不是最终早期脓毒症研究队列人数。

## 关键文件

- README.md：结果、方法段落和运行命令。
- docs/file_selection_zh.md：哪些材料能复用，哪些要替换。
- output/tables/source_manifest.csv：逐文件来源、分类和SHA256。
- data/gcs_long_mimic.csv：主数据表，不上传GitHub。
- output/tables/gcs_fix_check.csv：修正数量及分母。
- output/tables/gcs_manual_review_20.csv：20人逐例核查证据，不上传GitHub。
- output/figures/gcs_old_vs_new.png：修正前后分布。
- renv.lock、output/session_info.txt：运行环境。
'''
(ROOT/'docs/completion_zh.md').write_text(completion)
print('README and Chinese handoff written')
