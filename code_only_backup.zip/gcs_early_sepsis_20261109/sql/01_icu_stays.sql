-- Broad extraction frame, deliberately independent of old SAE cohort filters.
SELECT subject_id,hadm_id,stay_id,intime,outtime,
 LEAST(outtime,DATETIME_ADD(intime,INTERVAL 14 DAY)) AS extraction_end
FROM `physionet-data.mimiciv_3_1_icu.icustays`
