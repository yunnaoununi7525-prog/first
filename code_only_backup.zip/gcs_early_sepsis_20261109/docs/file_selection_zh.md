# 文件筛选与复用说明

本项目依据《工作计划 GCS轨迹 早期脓毒症 中文版》执行第 0、1 步。原件保持原位；old/ 是隔离副本，不是新分析的输入目录。逐文件来源、校验值和用途见 output/tables/source_manifest.csv；旧 CSV 的完整行列核对见 local_csv_audit.csv。

| 文件或材料 | 本次处理 | 可复用的部分与限制 |
|---|---|---|
| 修改版2.3 | 部分复用并归档 | BigQuery 连接、表名、化验查询思路；旧 SAE/GCS 筛选、缺失处理、时间窗和桌面依赖不能沿用 |
| 2.5 add_sae_requirement_variables.R | 部分复用并归档 | 脓毒症时间取 culture_time 与 sofa_time 的较晚值及单项缺失回退逻辑，供第2步审查；该版本只删除 SOFA 分项列名，没有重新查询这些分项 |
| ICD/ 编码与查询 | 后续临床核对后复用 | 排除编码是可编辑的代码/参考表，须先由临床核对，尚未用于新队列 |
| SAE_analysis.Rmd | 部分复用并归档 | 缺失检查和绘图思路；不能直接执行旧的样本筛选与危险因素结果 |
| make_eicu_hospital_missing_filter_table1.R | 第6步修改后复用 | 医院缺失检查、汇总表；须换成新队列、新 GCS 与相对路径 |
| 整理表格2.4 | 替换 | 使用旧 derived.gcs 和小时最低值，不能恢复 GCS 三分项或输注时间 |
| 画图、gcs_latent_trajectory_plots.R | 历史探索 | flexmix 与1000人抽样不满足新设计；可参考作图但不沿用类别 |
| 模型、三个模型 | 第7步参考 | ROC、SHAP 和模型接口；旧特征、切点和结局评估不能作为新结果 |
| SAE_prediction.Rmd | 历史方案 | 已被新设计取代 |
| Drive 05_fit_crlcmm (1).R | 第4步参考 | 使用 sepsis_time 起点及镇静协变量；与当前中文版计划不一致，不能直接运行作为主模型 |
| Drive 三份方案文档 | 设计依据与冲突核对 | execution_protocol、design_review、PlanB_prime 均已保存文本副本；本任务以中文版工作计划为准 |
| df_teacher 各版、df_sepsis3 各版、轨迹类别 CSV | 旧数据对照 | 可检查旧行列和追溯结果，不能代替原始分项、RASS 和输注区间，也不能用来筛新队列 |
| eICU 已导出 CSV 和医院表 | 第6步历史对照 | 不在本次重建 MIMIC GCS 时合并 |
| publication_ready、论文草稿、k=2/3 图 | 历史文稿与图 | 原结果不代表新方案已经执行，不作为当前结果复用 |
| 参考论文 PDF 和补充 DOCX | 方法参考 | 归档，不改写，不计作本研究结果 |
| 会议录像、CITI证书、Word锁文件 | 本次无需修改 | 不复制大型录像和证书；保留原处，不删除 |

## 尚未找到的原始生成脚本

- eICU 原始数据提取脚本：现有仓库与共享目录未找到。
- cam_icu.csv 和 delirium_drug.csv 的原始生成查询：旧脚本只有读取语句，未找到完整生成链路。药物需区分镇静输注和谵妄治疗，不能据名字猜测同义。
- df_sepsis3_clean_with_base_first_day_vars_with_complete_death_outcomes.csv 的完整生成脚本：旧脚本可提供片段，未找到该最终版本的完整可运行来源。
- ..._7d_y12... 类别文件：有相关 flexmix 代码，但缺少足以证明所有最终版本来源、参数与随机种子的完整链路。

以上缺口列入追溯清单。第1步重新从 MIMIC 原始表提取，不依赖这些旧文件，因此不会用猜测补齐旧来源。
