SELECT itemid,label,linksto,category,unitname
FROM `physionet-data.mimiciv_3_1_icu.d_items`
WHERE itemid IN (220739,223900,223901,228096)
 OR (linksto='inputevents' AND REGEXP_CONTAINS(LOWER(label),r'propofol|midazolam|dexmedetomidine|lorazepam'))
ORDER BY itemid
