-- Retain original infusion metadata; assess continuous-med eligibility in R.
-- Earlier starts are retained if the infusion overlaps an assessment lookback.
WITH stays AS (
 SELECT stay_id,intime,LEAST(COALESCE(outtime,DATETIME_ADD(intime,INTERVAL 14 DAY)),DATETIME_ADD(intime,INTERVAL 14 DAY)) AS stop_time
 FROM `physionet-data.mimiciv_3_1_icu.icustays`
), items AS (
 SELECT itemid,label FROM `physionet-data.mimiciv_3_1_icu.d_items`
 WHERE linksto='inputevents'
 AND REGEXP_CONTAINS(LOWER(label),r'propofol|midazolam|dexmedetomidine|lorazepam')
)
SELECT i.subject_id,i.hadm_id,i.stay_id,i.starttime,i.endtime,i.itemid,d.label,
 i.amount,i.amountuom,i.rate,i.rateuom,i.orderid,i.linkorderid,
 i.ordercategoryname,i.ordercategorydescription,i.statusdescription
FROM `physionet-data.mimiciv_3_1_icu.inputevents` i
JOIN items d USING(itemid)
JOIN stays s USING(stay_id)
WHERE (i.endtime>=DATETIME_SUB(s.intime,INTERVAL 4 HOUR) OR i.endtime IS NULL)
 AND i.starttime<s.stop_time
