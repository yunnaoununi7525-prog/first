SELECT nursingchartcelltypecat,nursingchartcelltypevallabel,nursingchartcelltypevalname,
nursingchartvalue,COUNT(*) AS n_records
FROM `physionet-data.eicu_crd.nursecharting`
WHERE REGEXP_CONTAINS(LOWER(CONCAT(COALESCE(nursingchartcelltypevallabel,''),' ',COALESCE(nursingchartcelltypevalname,''))),
r'glasgow|gcs|rass|richmond|sedation|delirium|cam-icu')
GROUP BY 1,2,3,4
