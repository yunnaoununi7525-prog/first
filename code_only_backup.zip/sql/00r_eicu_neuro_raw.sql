-- Minutes from ICU admission; preserve text, assessment and entry offsets.
SELECT n.* FROM `physionet-data.eicu_crd.nursecharting` n
JOIN `physionet-data.eicu_crd.patient` p USING(patientunitstayid)
WHERE n.nursingchartoffset BETWEEN -120 AND LEAST(p.unitdischargeoffset,20160)+120
AND REGEXP_CONTAINS(LOWER(CONCAT(COALESCE(n.nursingchartcelltypevallabel,''),' ',COALESCE(n.nursingchartcelltypevalname,''))),
r'glasgow|gcs|rass|richmond|sedation|delirium|cam-icu')
