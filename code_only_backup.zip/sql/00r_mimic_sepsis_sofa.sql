-- Preserve all source sepsis rows and source times. No onset/cohort selection in step 0.
SELECT * FROM `physionet-data.mimiciv_3_1_derived.sepsis3`
