-- Audit available GCS for unknown discharge times; do not invent an end time or final cohort eligibility.
SELECT c.subject_id,c.hadm_id,c.stay_id,c.charttime,c.itemid,c.value,c.valuenum
FROM `physionet-data.mimiciv_3_1_icu.chartevents` c
JOIN `physionet-data.mimiciv_3_1_icu.icustays` s USING(stay_id)
WHERE s.outtime IS NULL AND c.itemid IN (220739,223900,223901,228096)
AND c.charttime>=s.intime AND c.charttime<DATETIME_ADD(s.intime,INTERVAL 14 DAY)
