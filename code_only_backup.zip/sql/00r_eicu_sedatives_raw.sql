-- Point observations, NOT known start/end intervals. Never infer continuous exposure from this alone.
SELECT i.* FROM `physionet-data.eicu_crd.infusiondrug` i
JOIN `physionet-data.eicu_crd.patient` p USING(patientunitstayid)
WHERE i.infusionoffset BETWEEN -240 AND LEAST(p.unitdischargeoffset,20160)
AND REGEXP_CONTAINS(LOWER(i.drugname),r'propofol|diprivan|midazolam|versed|dexmedetomidine|precedex|lorazepam|ativan')
