-- GCS: ICU admission to min(discharge,14 days), upper boundary exclusive.
-- RASS has a two-hour margin so edge assessments receive the same rule.
WITH stays AS (
 SELECT stay_id,intime,LEAST(COALESCE(outtime,DATETIME_ADD(intime,INTERVAL 14 DAY)),DATETIME_ADD(intime,INTERVAL 14 DAY)) AS stop_time
 FROM `physionet-data.mimiciv_3_1_icu.icustays`
)
SELECT c.subject_id,c.hadm_id,c.stay_id,c.charttime,c.storetime,c.itemid,c.value,c.valuenum
FROM `physionet-data.mimiciv_3_1_icu.chartevents` c
JOIN stays s USING(stay_id)
WHERE c.itemid IN (220739,223900,223901,228096)
 AND ((c.itemid IN (220739,223900,223901) AND c.charttime>=s.intime AND c.charttime<s.stop_time)
   OR (c.itemid=228096 AND c.charttime>=DATETIME_SUB(s.intime,INTERVAL 2 HOUR)
                       AND c.charttime<=DATETIME_ADD(s.stop_time,INTERVAL 2 HOUR)))
