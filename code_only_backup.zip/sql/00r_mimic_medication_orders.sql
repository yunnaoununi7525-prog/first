-- PRESCRIBED orders, not confirmed administrations or delirium diagnoses.
-- Keep the old name pattern for provenance, but separate sedatives from antipsychotics.
SELECT p.subject_id,p.hadm_id,p.pharmacy_id,p.poe_id,p.poe_seq,
p.starttime,p.stoptime,p.drug,p.dose_val_rx,p.dose_unit_rx,p.route,
CASE WHEN REGEXP_CONTAINS(LOWER(drug),r'haloperidol|olanzapine|quetiapine|risperidone')
THEN 'antipsychotic_order' ELSE 'sedative_order' END AS exposure_type
FROM `physionet-data.mimiciv_3_1_hosp.prescriptions` p
WHERE REGEXP_CONTAINS(LOWER(drug),r'haloperidol|olanzapine|quetiapine|risperidone|lorazepam|midazolam|propofol')
AND EXISTS(SELECT 1 FROM `physionet-data.mimiciv_3_1_icu.icustays` s
WHERE s.hadm_id=p.hadm_id AND p.starttime<COALESCE(s.outtime,DATETIME_ADD(s.intime,INTERVAL 14 DAY)) AND (p.stoptime>=s.intime OR p.stoptime IS NULL))
