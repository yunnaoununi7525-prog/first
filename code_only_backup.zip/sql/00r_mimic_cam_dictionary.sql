SELECT * FROM `physionet-data.mimiciv_3_1_icu.d_items`
WHERE linksto='chartevents' AND REGEXP_CONTAINS(LOWER(label),r'cam-icu|delirium')
