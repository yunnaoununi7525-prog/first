SELECT g.stay_id,g.charttime,g.gcs AS gcs_derived_old
FROM `physionet-data.mimiciv_3_1_derived.gcs` g
JOIN `physionet-data.mimiciv_3_1_icu.icustays` s USING(stay_id)
WHERE g.charttime>=s.intime
 AND g.charttime<LEAST(COALESCE(s.outtime,DATETIME_ADD(s.intime,INTERVAL 14 DAY)),DATETIME_ADD(s.intime,INTERVAL 14 DAY))
