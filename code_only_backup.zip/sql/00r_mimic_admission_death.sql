-- Unfiltered ICU frame, not the final early-sepsis cohort. DATE dod is not an exact death timestamp.
SELECT s.subject_id,s.hadm_id,s.stay_id,s.intime,s.outtime,
a.admittime,a.dischtime,a.deathtime,a.hospital_expire_flag,a.admission_type,
a.admission_location,a.discharge_location,p.gender,p.anchor_age,p.anchor_year,p.anchor_year_group,p.dod
FROM `physionet-data.mimiciv_3_1_icu.icustays` s
JOIN `physionet-data.mimiciv_3_1_hosp.admissions` a USING(hadm_id,subject_id)
JOIN `physionet-data.mimiciv_3_1_hosp.patients` p USING(subject_id)
