-- All stays retained. Cohort eligibility and hospital missingness filtering belong to step 6.
SELECT * FROM `physionet-data.eicu_crd.patient`
