-- Raw source evidence only; unassessable or partial features are NOT negative.
SELECT c.subject_id,c.hadm_id,c.stay_id,c.charttime,c.storetime,c.itemid,d.label,c.value,c.valuenum
FROM `physionet-data.mimiciv_3_1_icu.chartevents` c
JOIN `physionet-data.mimiciv_3_1_icu.d_items` d USING(itemid)
JOIN `physionet-data.mimiciv_3_1_icu.icustays` s USING(stay_id)
WHERE d.linksto='chartevents' AND REGEXP_CONTAINS(LOWER(d.label),r'cam-icu|delirium')
AND c.charttime >= s.intime AND c.charttime < LEAST(COALESCE(s.outtime,DATETIME_ADD(s.intime,INTERVAL 14 DAY)),DATETIME_ADD(s.intime,INTERVAL 14 DAY))
