# Explicit one-time dependency installation; analysis scripts never install packages.
root <- Sys.getenv('SAE_PROJECT_ROOT',unset=getwd())
lib <- file.path(root,'.R-library'); dir.create(lib,recursive=TRUE,showWarnings=FALSE)
.libPaths(c(lib,.libPaths()))
need <- c('here','rprojroot','renv','data.table','bigrquery','DBI','ggplot2','lcmm','survival','jsonlite','digest','R.utils')
missing <- need[!vapply(need,requireNamespace,logical(1),quietly=TRUE)]
if (length(missing)) install.packages(missing,lib=lib,repos='https://cloud.r-project.org')
