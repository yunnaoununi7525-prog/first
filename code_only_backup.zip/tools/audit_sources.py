"""Read-only source audit; writes reports only inside the independent project."""
from pathlib import Path
import csv, hashlib, json
ROOT=Path(__file__).resolve().parents[1]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
manifest_path=ROOT/'output/tables/source_manifest.csv'
with manifest_path.open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f));fields=list(rows[0])
# Append cloud copies acquired after the initial snapshot, preserving original baselines.
known={r['copy_path'] for r in rows}
for p in sorted((ROOT/'old/cloud').iterdir()):
 if p.is_file() and str(p) not in known:
  rows.append(dict(source='google_drive_export',source_path=p.name,copy_path=str(p),bytes=str(p.stat().st_size),sha256=sha(p),classification='legacy_data_reference' if p.suffix=='.csv' else 'reference',reason='Shared folder snapshot; historical data or method reference'))
with manifest_path.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
audit=[]
for p in sorted((ROOT/'old').rglob('*.csv')):
 try:
  with p.open(encoding='utf-8-sig',newline='') as f:
   reader=csv.reader(f); header=next(reader); n=sum(1 for _ in reader)
  gcs=[c for c in header if any(s in c.lower() for s in ('gcs','rass','sedat','motor','verbal','charttime'))]
  audit.append(dict(file=str(p.relative_to(ROOT)),rows=n,columns=len(header),sha256=sha(p),gcs_related_columns=';'.join(gcs),raw_step1_ready=all(c in header for c in ('stay_id','charttime','itemid','valuenum','value'))))
 except Exception as e:
  audit.append(dict(file=str(p.relative_to(ROOT)),rows='',columns='',sha256=sha(p),gcs_related_columns='READ_ERROR:'+str(e),raw_step1_ready=False))
with (ROOT/'output/tables/local_csv_audit.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(audit[0]));w.writeheader();w.writerows(audit)
checks=[]
for r in rows:
 p=Path(r['source_path'])
 if r['source'] in ('desktop','previous_workspace'):
  actual=sha(p) if p.exists() else 'MISSING'
  checks.append(dict(source_path=str(p),original_sha256=r['sha256'],current_sha256=actual,unchanged=actual==r['sha256']))
with (ROOT/'output/tables/original_integrity_check.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(checks[0]));w.writeheader();w.writerows(checks)
assert all(c['unchanged'] for c in checks),'Original file integrity changed!'
cloud_csv=[r for r in audit if r['file'].startswith('old/cloud/')]
duplicates={Path(c['file']).name:[d['file'] for d in audit if d['sha256']==c['sha256'] and d['file']!=c['file']] for c in cloud_csv}
(ROOT/'output/provenance/cloud_local_duplicates.json').write_text(json.dumps(duplicates,ensure_ascii=False,indent=2))
print(json.dumps(dict(source_files=len(rows),csv_files_audited=len(audit),original_files_verified=len(checks),all_originals_unchanged=True,cloud_csv_identical_to_local=sum(bool(x) for x in duplicates.values())),ensure_ascii=False))
