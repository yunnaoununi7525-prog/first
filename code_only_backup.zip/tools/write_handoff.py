"""Generate an evidence summary; never overwrite README or human-reviewed completion status."""
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]
with (ROOT/'output/tables/gcs_fix_check.csv').open(encoding='utf-8-sig') as f:
    rows=list(csv.DictReader(f))
lines=['# Current GCS output summary','', 'Generated from gcs_fix_check.csv; not a completion or clinical-signoff claim.','', '| Metric | N | Denominator | Percent |','|---|---:|---:|---:|']
for x in rows:
    lines.append(f"| {x['metric']} | {x['n']} | {x['denominator']} | {x['percent']} |")
(ROOT/'output/tables/current_delivery_summary.md').write_text('\n'.join(lines)+'\n')
