"""Independent source-level check using Python standard library, not the R helpers."""
from pathlib import Path
from datetime import datetime,timedelta
import csv,gzip,math,json
ROOT=Path(__file__).resolve().parents[1]
def read(p):
 op=gzip.open if str(p).endswith('.gz') else open
 with op(p,'rt',encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def dt(s): return datetime.fromisoformat(s.replace('Z','+00:00')) if s else None
def num(s):return float(s) if s else None
def truth(s):return s.lower() in ('true','1')
def eq(a,b):return a==b or (a is None and b is None)
review=read(ROOT/'output/tables/gcs_manual_review_20.csv')
gcs=read(ROOT/'data/audit/raw_gcs_20_subjects.csv.gz')
rass=read(ROOT/'data/audit/raw_rass_20_subjects.csv.gz')
sed=read(ROOT/'data/audit/raw_sedatives_20_subjects.csv.gz')
checks=[]
for x in review:
 sid=x['stay_id']; t=dt(x['charttime'])
 raw=[r for r in gcs if r['stay_id']==sid and dt(r['charttime'])==t]
 comps={};conflicts={}
 for item,field,upper in [('220739','eye',4),('223900','verbal',5),('223901','motor',6)]:
  rows=[r for r in raw if r['itemid']==item]
  ett_flags=[r['value'].strip()=='No Response-ETT' for r in rows] if item=='223900' else [False]*len(rows)
  scores=[];invalid=False
  for r,ett in zip(rows,ett_flags):
   v=num(r['valuenum'])
   if not ett and v is not None:
    if v<1 or v>upper or int(v)!=v:invalid=True
    else:scores.append(v)
  conflict=len(set(scores))>1 or (any(ett_flags) and not all(ett_flags)) or invalid
  comps[field]=scores[0] if scores and not conflict else None
  conflicts[field]=conflict
 ett=any(r['itemid']=='223900' and r['value'].strip()=='No Response-ETT' for r in raw)
 imputed=ett and not conflicts['verbal'] and comps['eye'] is not None and comps['motor'] is not None
 if imputed:comps['verbal']=min(5,max(1,math.floor(-.3756+.5713*comps['motor']+.4233*comps['eye']+.5)))
 total=sum(comps.values()) if all(v is not None for v in comps.values()) else None
 nearby={}
 for r in rass:
  if r['stay_id']!=sid:continue
  v=num(r['valuenum']);rt=dt(r['charttime'])
  if v is not None and -5<=v<=4 and int(v)==v and abs((rt-t).total_seconds())<=7200:
   nearby.setdefault(rt,[]).append(v)
 rt=min(nearby,key=lambda q:(abs((q-t).total_seconds()),q>t)) if nearby else None
 rv=min(nearby[rt]) if rt is not None else None
 active=[]
 for r in sed:
  if r['stay_id']!=sid:continue
  rate=num(r['rate']);amount=num(r['amount']);a=dt(r['starttime']);b=dt(r['endtime'])
  eligible=(rate is not None and rate>0 and amount is not None and amount>0 and a is not None and b is not None and b>a and 'continuous' in r['ordercategorydescription'].lower() and r['statusdescription'].lower()!='rewritten')
  if eligible and a<=t and b>=t-timedelta(hours=4):active.append(r)
 usable=rv>=-2 if rv is not None else not active
 valid=usable and total is not None
 failures=[]
 for k,v in comps.items():
  if not eq(v,num(x[k])):failures.append(k)
 for k,a,b in [('ett',ett,truth(x['ett'])),('verbal_imputed',imputed,truth(x['verbal_imputed'])),
                ('rass_nearby',rv,num(x['rass_nearby'])),('sedative_running',bool(active),truth(x['sedative_running'])),
                ('gcs_total_all',total,num(x['gcs_total_all'])),('valid',valid,truth(x['valid'])),
                ('gcs_total',total if valid else None,num(x['gcs_total']))]:
  if not eq(a,b):failures.append(k)
 x['review_status']='independent_source_check_passed' if not failures else 'FAILED'
 x['review_notes']='Independent Python recomputation of raw components, nearest RASS and infusion overlap; clinical review not implied.'
 x['raw_component_records']=str(len(raw));x['nearby_rass_times']=str(len(nearby));x['overlapping_infusions']=str(len(active))
 if failures:x['review_notes']='MISMATCH: '+','.join(failures)
 checks.append(dict(ett=ett,imputed=imputed,valid=valid,all_total=total,old=num(x['gcs_derived_old']),rass=rv,recent_infusion=bool(active),passed=not failures))
assert len({r['subject_id'] for r in review})==20,'Expected 20 distinct sampled subjects'
assert all(x['passed'] for x in checks),checks
with (ROOT/'output/tables/gcs_manual_review_20.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(review[0]));w.writeheader();w.writerows(review)
report={'subjects_checked':len(review),'all_passed':True,'ett_assessments_checked':sum(c['ett'] for c in checks),
        'method':'Independent Python source-record recomputation; not clinical validation',
        'case_evidence_without_identifiers':checks}
(ROOT/'output/provenance/source_review_20.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
