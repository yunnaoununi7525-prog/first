source('R/00_setup.R')
source(here::here('R/recovery_helpers.R'))
source(here::here('R/bq_helpers.R'))
counts <- fread(here::here('output/tables/recovered_source_counts.csv'))
expected <- sub('[.]sql$','',list.files(here::here('sql'),pattern='^00r_.*[.]sql$'))
validate_recovery_manifest(counts,expected)
for (name in counts$query) {
 sql <- paste(readLines(here::here('sql',paste0(name,'.sql')),warn=FALSE),collapse='\n')
 meta <- jsonlite::read_json(here::here('output/provenance',paste0(name,'.json')))
 validate_cache_metadata(meta,digest::digest(sql,algo='sha256',serialize=FALSE))
 d <- fread(here::here('data/raw',paste0(name,'.csv.gz')))
 stopifnot(nrow(d)==counts[query==name,n_rows],ncol(d)==counts[query==name,n_columns],nrow(d)==meta$rows)
 key <- switch(name, '00r_eicu_neuro_raw'='nursingchartid','00r_eicu_patient'='patientunitstayid',
  '00r_eicu_sedatives_raw'='infusiondrugid','00r_mimic_admission_death'='stay_id',NULL)
 if (!is.null(key)) {
  if (!key %in% names(d)) stop(name,': primary key column missing')
  if(anyNA(d[[key]])) stop(name,': missing primary identifiers')
  if(anyDuplicated(d[[key]])) stop(name,': duplicated primary identifiers')
 }
 if (name %in% c('00r_eicu_neuro_raw','00r_eicu_sedatives_raw')) {
  pat <- fread(here::here('data/raw/00r_eicu_patient.csv.gz'),select=c('patientunitstayid','unitdischargeoffset'))
  joined <- merge(d,pat,by='patientunitstayid',all.x=TRUE,sort=FALSE)
  stopifnot(nrow(joined)==nrow(d),!anyNA(joined$unitdischargeoffset))
  if (name=='00r_eicu_neuro_raw') stopifnot(all(joined$nursingchartoffset>=-120 & joined$nursingchartoffset<=pmin(joined$unitdischargeoffset,20160)+120))
  else stopifnot(all(joined$infusionoffset>=-240 & joined$infusionoffset<=pmin(joined$unitdischargeoffset,20160)))
  rm(joined,pat)
 }
 cat('PASS',name,nrow(d),'\n');rm(d);gc()
}
cat('RECOVERED SOURCES ACCEPTANCE PASSED\n')
