source('R/gcs_helpers.R')
library(data.table)
check <- function(name, actual, expected) {
  if (!isTRUE(all.equal(actual, expected, check.attributes=FALSE))) stop(name, ': ', paste(actual, collapse=','), ' != ', paste(expected,collapse=','))
  cat('PASS ', name, '\n', sep='')
}
t0 <- as.POSIXct('2150-01-01 12:00:00',tz='UTC')
raw <- data.table(stay_id=rep(1:8,each=3), charttime=rep(t0,24), itemid=rep(c(220739L,223900L,223901L),8),
                  valuenum=c(4,5,6, 1,0,1, 4,0,6, 4,5,6, 4,5,6, 4,5,6, 4,5,6, 4,5,6),
                  value=rep(c('4 Spontaneously','5 Oriented','6 Obeys Commands'),8))
raw[itemid==223900L & stay_id %in% c(2,3),value:='No Response-ETT']
raw <- raw[!(stay_id==4 & itemid==220739L)]
raw <- rbind(raw,raw[stay_id==1 & itemid==220739L])
raw <- rbind(raw,data.table(stay_id=5L, charttime=t0,itemid=223901L,valuenum=2,value='2 Abnormal extension'))
x <- build_gcs_assessments(raw)
check('one row per stay and time',nrow(x),8L)
check('normal score',x[stay_id==1,gcs_total_all],15)
check('ETT lower clipping',x[stay_id==2,verbal],1)
check('ETT upper clipping',x[stay_id==3,verbal],5)
check('ETT low total',x[stay_id==2,gcs_total_all],3)
check('missing eye stays missing',is.na(x[stay_id==4,gcs_total_all]),TRUE)
check('conflicting motor stays missing',is.na(x[stay_id==5,motor]),TRUE)
check('conflict flagged',x[stay_id==5,motor_conflict],TRUE)
check('identical duplicate counted',x[stay_id==1,eye_n_raw],2L)
rass <- data.table(stay_id=c(1,1,2,2,3,6,7),charttime=t0+c(-1800,1800,-1000,500,-7200,7201,0),valuenum=c(-3,0,-1,-4,-2,-1,-5))
sed <- data.table(stay_id=c(3,6,7,8),starttime=t0+c(-20000,-20000,-500,-14400),endtime=t0+c(-18000,-1000,500,-14000))
y <- annotate_gcs(x,rass,sed)
check('equal distance prefers prior RASS',y[stay_id==1,rass_nearby],-3)
check('nearest RASS wins over any awake value',y[stay_id==2,valid],FALSE)
check('two-hour boundary included',y[stay_id==3,valid],TRUE)
check('completed remote infusion not in four-hour window',y[stay_id==3,sedative_running],FALSE)
check('old infusion overlapping four-hour window detected',y[stay_id==6,sedative_running],TRUE)
check('RASS outside two hours cannot validate',y[stay_id==6,valid],FALSE)
check('nearby deep RASS cannot fall back to no sedative',y[stay_id==7,valid],FALSE)
check('four-hour boundary included',y[stay_id==8,sedative_running],TRUE)
check('invalid primary GCS masked',all(is.na(y[valid==FALSE,gcs_total])),TRUE)
check('all-assessment GCS retained',y[stay_id==1,gcs_total_all],15)
empty_rass <- rass[0]; empty_sed <- sed[0]
z <- annotate_gcs(x,empty_rass,empty_sed)
check('no RASS and no infusion validates complete assessments',z[stay_id==1,valid],TRUE)
check('missing total never becomes normal',z[stay_id==4,valid],FALSE)
raw2 <- copy(raw[stay_id==1]); raw2[1,valuenum:=7]
check('out-of-range score becomes missing',is.na(build_gcs_assessments(raw2)$eye),TRUE)
check('standard round-half-up',round_half_up(c(1.5,2.5,3.49)),c(2,3,3))
sed_test <- data.table(starttime=rep(t0,5),endtime=t0+c(0,-60,60,60,60),rate=rep(1,5),amount=c(0,-1,1,1,1),
                      ordercategorydescription=c('Continuous Med','Continuous Med','Continuous Med','Drug Push','Continuous Med'),
                      statusdescription=c('FinishedRunning','FinishedRunning','FinishedRunning','FinishedRunning','Rewritten'))
check('only actual positive continuous infusions count',prepare_sedatives(sed_test)$include_infusion,c(FALSE,FALSE,TRUE,FALSE,FALSE))
sed_test2<-copy(sed_test[3]);sed_test2[,endtime:=starttime]
check('positive-dose invalid interval stops classification',inherits(try(prepare_sedatives(sed_test2),silent=TRUE),'try-error'),TRUE)

cat('ALL TESTS PASSED\n')
