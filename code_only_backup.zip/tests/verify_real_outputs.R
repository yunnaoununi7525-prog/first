source('R/00_setup.R')
x<-fread(here::here('data/gcs_long_mimic.csv'))
qc<-fread(here::here('output/tables/gcs_fix_check.csv'))
stopifnot(nrow(x)>0L,!anyDuplicated(x[,.(stay_id,charttime)]))
for (k in c('eye','verbal','motor')) {
 upper<-c(eye=4,verbal=5,motor=6)[[k]]
 stopifnot(all(is.na(x[[k]]) | (x[[k]]>=1 & x[[k]]<=upper & x[[k]]==floor(x[[k]]))))
}
stopifnot(all(is.na(x$gcs_total_all) | x$gcs_total_all==x$eye+x$verbal+x$motor),
          all(is.na(x$gcs_total)==!x$valid),
          all(x[valid==TRUE,gcs_total]==x[valid==TRUE,gcs_total_all]),
          all(is.na(x$rass_delta_minutes) | abs(x$rass_delta_minutes)<=120),
          all(x$day>=0 & x$day<14),
          all(x$charttime>=x$intime & x$charttime<x$extraction_end))
z<-x[verbal_imputed==TRUE]
stopifnot(all(z$ett),all(z$verbal==pmin(5,pmax(1,floor(-.3756+.5713*z$motor+.4233*z$eye+.5)))))
expected_valid <- ifelse(!is.na(x$rass_nearby),x$rass_nearby>=-2,!x$sedative_running)&!is.na(x$gcs_total_all)
stopifnot(identical(expected_valid,x$valid))
stopifnot(qc[metric=='valid_assessments',n]==sum(x$valid),qc[metric=='ett_assessments',denominator]==nrow(x))
pd<-fread(here::here('output/tables/gcs_patient_day_coverage.csv'))
stopifnot(sum(pd$n_patient_days)==qc[metric=='patient_days_with_valid_gcs',denominator],
          sum(pd$n_with_valid_gcs)==qc[metric=='patient_days_with_valid_gcs',n])
review<-fread(here::here('output/tables/gcs_manual_review_20.csv'))
stopifnot(uniqueN(review$subject_id)==20L,all(review$review_status=='independent_source_check_passed'))
smoke<-fread(here::here('output/tables/lcmm_smoke_result.csv'))
stopifnot(smoke$conv==1L,is.finite(smoke$loglik))
cat('REAL OUTPUT ACCEPTANCE PASSED\n')
cat('Assessments:',nrow(x),'Valid:',sum(x$valid),'Subjects:',uniqueN(x$subject_id),'\n')
stopifnot(all(is.na(x[boundary_status=='missing_outtime',outtime])),
          all(!x[boundary_status=='missing_outtime',coverage_eligible]),
          sum(x$boundary_status=='missing_outtime')==qc[metric=='assessments_unknown_outtime',n])
stays<-fread(here::here('data/raw/icu_stays.csv.gz'))
known_days<-ceiling(as.numeric(difftime(stays[!is.na(outtime),extraction_end],stays[!is.na(outtime),intime],units='days')))
stopifnot(sum(known_days)==sum(pd$n_patient_days))
frozen<-as.numeric(jsonlite::read_json(here::here('data/audit/initial_random20_subject_ids.json'),simplifyVector=TRUE))
stopifnot(setequal(frozen,review$subject_id))
case_review<-fread(here::here('data/audit/gcs_20_case_by_case_review.csv'))
stopifnot(setequal(case_review$subject_id,review$subject_id))
cat('Boundary denominator and frozen review sample verified\n')
