# Copy to settings.local.R; it is ignored by Git. Do not put credentials here.
settings <- list(
  billing_project = Sys.getenv('SAE_BQ_PROJECT'),
  bq_email = Sys.getenv('SAE_BQ_EMAIL'),
  maximum_bytes_billed = 100 * 1024^3,
  mimic_version = 'MIMIC-IV 3.1',
  eicu_version = 'eICU-CRD 2.0',
  extraction_days = 14L,
  audit_seed = 20261109L,
  compute_environment = 'Local laptop; no laboratory server confirmed'
)
